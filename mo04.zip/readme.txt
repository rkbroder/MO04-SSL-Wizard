MO04 - WebSphere MQ SSL Wizard V2.0 Readme

Contents of mo04.zip...
        - wmqsslwizard.jar              - WMQ SSL Wizard executable  (java -jar wmqsslwizard.jar)
        - mo04.pdf                      - Help documentation
        - sample_mca_channel.data       - Sample data file (java -jar wmqsslwizard.jar sample_mca_channel.data)
        - sample_client.data            - Sample data file (java -jar wmqsslwizard.jar sample_mca_channel.data)
        - client_samples directory      - Contains sample source and binaries for WMQ SSL client applications
        - license directory             - Contains licenses
        - images directory              - Contains images for WMQ SSL Wizard panels






