/********************************************************************/
/*                                                                  */
/* Program name: SSLSample                                          */
/*                                                                  */
/* Description: Sample Java program that demonstrates how to        */
/*              specify SSL client connection information for a     */
/*              MQQueueManager connection.                          */
/*                                                                  */
/* <START_COPYRIGHT>                                                */
/* Licensed Materials - Property of IBM                             */
/*                                                                  */
/* (C) Copyright IBM Corp. 2006,2009 All Rights Reserved.           */
/*                                                                  */
/* US Government Users Restricted Rights - Use, duplication or      */
/* disclosure restricted by GSA ADP Schedule Contract with          */
/* IBM Corp.                                                        */
/* <END_COPYRIGHT>                                                  */
/*                                                                  */
/********************************************************************/
/*                                                                  */
/* Overview:                                                        */
/*                                                                  */
/*   This sample is provided with WebSphere MQ SupportPac MO04 -    */
/*   WebSphere MQ SSL Wizard. The wizard will generate command line */
/*   options to be used with this program.                          */
/*                                                                  */
/*   It is assumed that the SSL server connection channel and other */
/*   SSL administration, as instructed by the wizard, has been      */
/*   completed before running this program.                         */
/*                                                                  */
/*   If the SSL connection is successful the program should output: */
/*                                                                  */
/*      "Connection Successful!"                                    */
/*                                                                  */
/********************************************************************/
/*                                                                  */
/* Function:                                                        */
/*                                                                  */
/*   SSLSample is a sample Java program that demonstrates how to    */
/*   supply SSL information for a client connection on a            */
/*   MQQueueManager connection.                                     */
/*                                                                  */
/*   The sample simply connects to the queue manager by             */
/*   constructing the MQQueueManager object and then disconnects    */
/*   using the MQQueueManager disconnect method.                    */
/*                                                                  */
/********************************************************************/
/*                                                                  */
/* Usage:                                                           */
/*                                                                  */
/*   SSLSample has 7 parameters, all of which are mandatory:        */
/*                                                                  */
/*     java SSLSample Conname Port SvrconnChannelName               */
/*             QMgrName SSLCiph SSLKeyr SSLKeyrPassword             */
/*                                                                  */
/*   The parameters are:                                            */
/*                                                                  */
/*     Conname     - the connection name of the server queue        */
/*                   manager in the same format as the CONNAME      */
/*                   parameter on the MQSC DEFINE CHANNEL command,  */
/*                   but without the port specified.                */
/*                                                                  */
/*     Port        - the connection port of the server queue        */
/*                   manager.                                       */
/*                                                                  */
/*     SvrconnChannelName                                           */
/*                 - the name of the server connection channel      */
/*                   on the server queue manager with which the     */
/*                   sample program will try to connect.            */
/*                                                                  */
/*     QMgrName    - the name of the server queue manager.          */
/*                                                                  */
/*     SSLCiph     - the SSL CipherSpec.                            */
/*                                                                  */
/*     SSLKeyr     - the name of a single store, which is both the  */
/*                   keystore and truststore.                       */
/*                                                                  */
/*     SSLKeyrPassword                                              */
/*                 - the SSL key repository password.               */
/*                                                                  */
/*   For example:                                                   */
/*                                                                  */
/*     java SSLSample myhost1 1414 SSL.SVRCONN QM1 NULL_MD5         */
/*                                    C:\mq\ssl\client.kdb password */
/*                                                                  */
/********************************************************************/
import java.util.Hashtable;

import com.ibm.mq.*; //Include the WebSphere MQ classes for Java package
import com.ibm.mq.constants.MQConstants; 

public class SSLSample {

  // define the parms
  private static String conname ;
  private static String port    ;
  private static String channel ;
  private static String qmgr    ;
  private static String sslciph ;
  private static String sslkeyr ;
  private static String sslpass ;
  
  public static void main(String args[]) {
    /****************************************************************/
    /* Check for correct number of arguments                        */
    /****************************************************************/
    if (args.length == 7) {
      conname = args[0];
      port    = args[1];
      channel = args[2];
      qmgr    = args[3];
      sslciph = args[4];
      sslkeyr = args[5];
      sslpass = args[6];
    }
    else {
      System.out.println("Usage parms: Conname Port Channel Qmgr SSLCiph SSLStore SSLKeyStorePassword");
      System.out.println("     NOTE - SSLStore is the name of a single store, which is both the keystore and truststore.");
      return;
    }
  
    new SSLSample().runSample();     
  }

  public void runSample() {
    //System.setProperty("javax.net.debug", "true");

    /****************************************************************/
    /* Utilise the arguments                                        */
    /****************************************************************/
    System.setProperty("javax.net.ssl.trustStore", sslkeyr );
    System.setProperty("javax.net.ssl.keyStore", sslkeyr );
    System.setProperty("javax.net.ssl.keyStorePassword", sslpass );
    MQEnvironment.hostname       = conname;
    MQEnvironment.port           = Integer.parseInt(port);
    MQEnvironment.channel        = channel;
    MQEnvironment.properties.put(MQConstants.SSL_CIPHER_SUITE_PROPERTY,sslciph); 

    /****************************************************************/
    /* Print out parms                                              */
    /****************************************************************/
    System.out.println("Connecting to:");
    System.out.println("  Conname = " + MQEnvironment.hostname);
    System.out.println("  Port = " + MQEnvironment.port);
    System.out.println("  Channel = " + MQEnvironment.channel);
    System.out.println("  Qmgr = " + qmgr);
    System.out.println("  SSLCiph = "+ MQEnvironment.properties.get(MQConstants.SSL_CIPHER_SUITE_PROPERTY));
    System.out.println("  SSLTrustStore = "+ System.getProperty("javax.net.ssl.trustStore"));
    System.out.println("  SSLKeyStore = "+ System.getProperty("javax.net.ssl.keyStore"));
    System.out.println("  SSLKeyStorePassword = "+ System.getProperty("javax.net.ssl.keyStorePassword"));

    try {

      /**************************************************************/
      /* Connect to queue manager                                   */
      /**************************************************************/
      System.out.println("Connecting...");
      MQQueueManager qMgr = new MQQueueManager(qmgr);
      System.out.println("Connection successful!");

      /**************************************************************/
      /* Disconnect from queue manager                              */
      /**************************************************************/
      System.out.println("Disconnecting from the Queue Manager");
      qMgr.disconnect();
      System.out.println("Done!");
    }
    catch (MQException ex) {
      System.out.println("A WebSphere MQ Error occured : Completion Code "
                + ex.completionCode + " Reason Code " + ex.reasonCode);
    }
  }
} 